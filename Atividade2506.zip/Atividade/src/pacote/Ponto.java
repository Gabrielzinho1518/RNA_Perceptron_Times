package pacote;

public class Ponto {
    public int limiar;
    public double x;
    public double y;
    
    public Ponto(double x, double y)
    {
        this.x = x;
        this.y = y;
    }
}